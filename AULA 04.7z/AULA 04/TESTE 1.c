#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <math.h>
#include <string.h>
main()
{
    FILE *f = fopen ("teste.txt", "w");
    int x,tam;
    char nome[30];
   for(x=1; x <= 4; x++)

    {
        printf("Digite um nome; ");
        gets(nome);
        // na variavel tam ficar� guardado quantas letras tem o nome
        tam = strlen(nome);
        printf("\nEsse nome tem %d\ letras. \n\n", tam);
        fputs(nome,f);
    }
    fclose(f);

    printf("\n\n");
    system("pause");
    return 0;





}
