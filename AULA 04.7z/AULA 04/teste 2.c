#include <stdio.h>
int main(int argc, char*argv [])
{
    FILE *f = fopen ("teste.txt", "w");
    char i;
    for (i='a'; i<='z'; i++)
        fputc(i,f);
        fclose(f);
}
